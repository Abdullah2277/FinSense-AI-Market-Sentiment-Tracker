import 'package:flutter/material.dart';
import 'package:background_fetch/background_fetch.dart';
import 'tasks/services/news_service.dart';
import 'tasks/services/notification_service.dart';
import 'tasks/screens/news_list_screen.dart';

// Background fetch event handler
void backgroundFetchHeadlessTask(HeadlessTask task) async {
  String taskId = task.taskId;
  bool timeout = task.timeout;
  if (timeout) {
    BackgroundFetch.finish(taskId);
    return;
  }
  try {
    await NewsService().fetchAndAnalyzeNewsIncremental();
  } catch (e) {
    // Handle error if needed
  }
  BackgroundFetch.finish(taskId);
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await NotificationService().init();

  // Configure background fetch
  BackgroundFetch.registerHeadlessTask(backgroundFetchHeadlessTask);
  BackgroundFetch.configure(
    BackgroundFetchConfig(
      minimumFetchInterval: 15, // minutes
      stopOnTerminate: false,
      enableHeadless: true,
      requiredNetworkType: NetworkType.ANY,
    ),
    (String taskId) async {
      // This is the fetch event callback
      try {
        await NewsService().fetchAndAnalyzeNewsIncremental();
      } catch (e) {
        // Handle error if needed
      }
      BackgroundFetch.finish(taskId);
    },
    (String taskId) async {
      // Timeout callback
      BackgroundFetch.finish(taskId);
    },
  );

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Finance News Sentiment',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: Color(0xFFF5F7FA),
        appBarTheme: AppBarTheme(
          elevation: 0,
          backgroundColor: Colors.white,
          iconTheme: IconThemeData(color: Colors.black87),
          titleTextStyle: TextStyle(
            color: Colors.black87,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      home: NewsListScreen(),
    );
  }
}
