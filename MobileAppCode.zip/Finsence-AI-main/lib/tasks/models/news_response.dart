import "news_article.dart";

class NewsResponse {
  final int found;
  final int returned;
  final List<NewsArticle> articles;

  NewsResponse({
    required this.found,
    required this.returned,
    required this.articles,
  });

  factory NewsResponse.fromJson(Map<String, dynamic> json) {
    var articlesList = (json['data'] as List)
        .map((article) => NewsArticle.fromJson(article))
        .toList();

    return NewsResponse(
      found: json['meta']['found'] ?? 0,
      returned: json['meta']['returned'] ?? 0,
      articles: articlesList,
    );
  }
}
