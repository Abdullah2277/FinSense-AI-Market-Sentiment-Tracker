class NewsArticle {
  final String uuid;
  final String title;
  final String description;
  final String url;
  final String? imageUrl;
  final String publishedAt;
  final String source;
  String sentiment;

  NewsArticle({
    required this.uuid,
    required this.title,
    required this.description,
    required this.url,
    this.imageUrl,
    required this.publishedAt,
    required this.source,
    this.sentiment = 'pending',
  });

  factory NewsArticle.fromJson(Map<String, dynamic> json) {
    return NewsArticle(
      uuid: json['uuid'] ?? '',
      title: json['title'] ?? '',
      description: json['description'] ?? '',
      url: json['url'] ?? '',
      imageUrl: json['image_url'],
      publishedAt: json['published_at'] ?? '',
      source: json['source'] ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'uuid': uuid,
      'title': title,
      'description': description,
      'url': url,
      'image_url': imageUrl,
      'published_at': publishedAt,
      'source': source,
      'sentiment': sentiment,
    };
  }
}
