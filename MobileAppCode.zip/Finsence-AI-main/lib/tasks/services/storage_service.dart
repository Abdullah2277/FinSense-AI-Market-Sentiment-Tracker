// services/storage_service.dart
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/news_article.dart';

class StorageService {
  static const String ARTICLES_KEY = 'cached_articles';

  Future<void> saveArticles(List<NewsArticle> articles) async {
    final prefs = await SharedPreferences.getInstance();
    final articlesJson = articles.map((a) => a.toJson()).toList();
    await prefs.setString(ARTICLES_KEY, json.encode(articlesJson));
  }

  Future<List<NewsArticle>> getArticles() async {
    final prefs = await SharedPreferences.getInstance();
    final articlesString = prefs.getString(ARTICLES_KEY);

    if (articlesString == null) return [];

    final List<dynamic> articlesJson = json.decode(articlesString);
    return articlesJson.map((json) => NewsArticle.fromJson(json)).toList();
  }
}
