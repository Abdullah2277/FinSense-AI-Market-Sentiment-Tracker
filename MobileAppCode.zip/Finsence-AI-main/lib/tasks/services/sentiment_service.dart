// services/sentiment_service.dart
import 'dart:convert';
import 'package:http/http.dart' as http;

class SentimentService {
  // Local FinBERT API endpoint
  // Change this to your deployed API URL or use ngrok for development
  // HuggingFace Space API endpoint
  static const String FINBERT_API_URL =
      'https://hussainr-finsense.hf.space/predict';

  // Timeout for API requests
  static const Duration REQUEST_TIMEOUT = Duration(seconds: 30);

  Future<String> analyzeSentiment(String text) async {
    try {
      // Call HuggingFace Space API
      final response = await http
          .post(
            Uri.parse(FINBERT_API_URL),
            headers: {
              'Content-Type': 'application/json',
            },
            body: json.encode({'text': text}),
          )
          .timeout(REQUEST_TIMEOUT);

      if (response.statusCode == 200) {
        final result = json.decode(response.body);
        // Expecting: { "sentiment": ..., "confidence": ..., ... }
        if (result is Map && result.containsKey('sentiment')) {
          String sentiment = result['sentiment'].toString().toLowerCase();
          print(
              'API sentiment: $sentiment (confidence: ${result['confidence']})');
          return sentiment;
        }
      } else {
        print('API error: ${response.statusCode} - ${response.body}');
      }

      // Fallback: Simple keyword-based sentiment (for development/testing)
      return _fallbackSentimentAnalysis(text);
    } catch (e) {
      print('Error analyzing sentiment: $e');
      return _fallbackSentimentAnalysis(text);
    }
  }

  /// Batch analyze multiple texts at once (more efficient)
  Future<List<String>> analyzeSentimentBatch(List<String> texts) async {
    try {
      final response = await http
          .post(
            Uri.parse('$FINBERT_API_URL/batch_analyze'),
            headers: {
              'Content-Type': 'application/json',
            },
            body: json.encode({'texts': texts}),
          )
          .timeout(REQUEST_TIMEOUT);

      if (response.statusCode == 200) {
        final result = json.decode(response.body);

        if (result.containsKey('results')) {
          List<String> sentiments = [];
          for (var item in result['results']) {
            if (item.containsKey('sentiment')) {
              sentiments.add(item['sentiment'].toString().toLowerCase());
            } else {
              sentiments.add('neutral');
            }
          }
          return sentiments;
        }
      }

      // Fallback: Analyze individually
      List<String> sentiments = [];
      for (var text in texts) {
        sentiments.add(await analyzeSentiment(text));
      }
      return sentiments;
    } catch (e) {
      print('Error in batch sentiment analysis: $e');

      // Fallback: Analyze individually
      List<String> sentiments = [];
      for (var text in texts) {
        sentiments.add(_fallbackSentimentAnalysis(text));
      }
      return sentiments;
    }
  }

  /// Check if FinBERT API is available
  Future<bool> checkApiHealth() async {
    try {
      final response = await http
          .get(Uri.parse('$FINBERT_API_URL/health'))
          .timeout(Duration(seconds: 5));

      if (response.statusCode == 200) {
        final result = json.decode(response.body);
        return result['status'] == 'healthy' && result['model_loaded'] == true;
      }
      return false;
    } catch (e) {
      print('FinBERT API health check failed: $e');
      return false;
    }
  }

  String _fallbackSentimentAnalysis(String text) {
    final lowerText = text.toLowerCase();

    final positiveWords = [
      'growth',
      'profit',
      'surge',
      'gain',
      'rise',
      'up',
      'increase',
      'success',
      'win',
      'boost',
      'strong'
    ];
    final negativeWords = [
      'loss',
      'decline',
      'fall',
      'drop',
      'down',
      'weak',
      'decrease',
      'fail',
      'lawsuit',
      'damages',
      'slump'
    ];

    int positiveCount = 0;
    int negativeCount = 0;

    for (var word in positiveWords) {
      if (lowerText.contains(word)) positiveCount++;
    }

    for (var word in negativeWords) {
      if (lowerText.contains(word)) negativeCount++;
    }

    if (positiveCount > negativeCount) return 'positive';
    if (negativeCount > positiveCount) return 'negative';
    return 'neutral';
  }
}
