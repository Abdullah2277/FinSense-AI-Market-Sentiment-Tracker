import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';
import '../models/news_article.dart';
import '../models/news_response.dart';
import 'sentiment_service.dart';
import 'storage_service.dart';

class NewsService {
  static const String API_KEY = 'et6WXsfCaHJTTMAyaS8eCHYxpkH49eD2RJhAQoXA';
  static const String BASE_URL = 'https://api.marketaux.com/v1/news/all';

  final SentimentService _sentimentService = SentimentService();
  final StorageService _storageService = StorageService();

  // Notifier for incremental updates
  final ValueNotifier<List<NewsArticle>> newsNotifier = ValueNotifier([]);

  /// Incremental fetch and analyze: updates UI as each article is processed
  Future<void> fetchAndAnalyzeNewsIncremental() async {
    newsNotifier.value = [];
    try {
      final response = await http.get(
        Uri.parse(
            '$BASE_URL?api_token=$API_KEY&filter_entities=true&limit=50&language=en'),
      );
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        final newsResponse = NewsResponse.fromJson(jsonData);

        for (var article in newsResponse.articles) {
          if (article.description.isNotEmpty) {
            article.sentiment =
                await _sentimentService.analyzeSentiment(article.description);
          }
          // Add article and notify listeners
          newsNotifier.value = List.from(newsNotifier.value)..add(article);
        }
        await _storageService.saveArticles(newsNotifier.value);
      } else {
        throw Exception('Failed to load news');
      }
    } catch (e) {
      print('Error fetching news: $e');
      newsNotifier.value = await _storageService.getArticles();
    }
  }

  Future<List<NewsArticle>> getCachedNews() async {
    return await _storageService.getArticles();
  }
}
