import 'package:flutter/material.dart';
import '../models/news_article.dart';
import '../services/news_service.dart';
import 'news_detail_screen.dart';
import 'webview_screen.dart';

class NewsListScreen extends StatefulWidget {
  @override
  _NewsListScreenState createState() => _NewsListScreenState();
}

class _NewsListScreenState extends State<NewsListScreen> {
  final NewsService _newsService = NewsService();
  bool _isLoading = true;
  String _filterSentiment = 'all';
  Map<String, String> _sentimentCache = {};

  @override
  void initState() {
    super.initState();
    _newsService.newsNotifier.addListener(_onNewsUpdated);
    _loadNews();
  }

  @override
  void dispose() {
    _newsService.newsNotifier.removeListener(_onNewsUpdated);
    super.dispose();
  }

  void _onNewsUpdated() {
    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _loadNews() async {
    setState(() => _isLoading = true);
    try {
      await _newsService.fetchAndAnalyzeNewsIncremental();
    } catch (e) {
      setState(() => _isLoading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error loading news: $e')),
      );
    }
  }

  List<NewsArticle> get _filteredArticles {
    final articles = _newsService.newsNotifier.value;
    if (_filterSentiment == 'all') return articles;
    return articles.where((a) => a.sentiment == _filterSentiment).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Finance News Sentiment'),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: _loadNews,
          ),
        ],
      ),
      body: Column(
        children: [
          _buildFilterChips(),
          Expanded(
            child: ValueListenableBuilder<List<NewsArticle>>(
              valueListenable: _newsService.newsNotifier,
              builder: (context, articles, _) {
                if (_isLoading) {
                  return Center(child: CircularProgressIndicator());
                } else if (articles.isEmpty) {
                  return _buildEmptyState();
                } else {
                  return _buildNewsList();
                }
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChips() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      color: Colors.white,
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            _buildFilterChip('All', 'all'),
            SizedBox(width: 8),
            _buildFilterChip('Positive', 'positive'),
            SizedBox(width: 8),
            _buildFilterChip('Neutral', 'neutral'),
            SizedBox(width: 8),
            _buildFilterChip('Negative', 'negative'),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterChip(String label, String value) {
    final isSelected = _filterSentiment == value;
    return FilterChip(
      label: Text(label),
      selected: isSelected,
      onSelected: (selected) {
        setState(() => _filterSentiment = value);
      },
      selectedColor: _getSentimentColor(value).withOpacity(0.3),
      checkmarkColor: _getSentimentColor(value),
    );
  }

  Widget _buildNewsList() {
    final filtered = _filteredArticles;

    if (filtered.isEmpty) {
      return Center(
        child: Text('No ${_filterSentiment} news found'),
      );
    }

    // Show at least 20 latest news if available
    final int newsToShow = filtered.length >= 20 ? 20 : filtered.length;

    return RefreshIndicator(
      onRefresh: _loadNews,
      child: ListView.builder(
        padding: EdgeInsets.all(16),
        itemCount: newsToShow,
        itemBuilder: (context, index) {
          return _buildNewsCard(filtered[index]);
        },
      ),
    );
  }

  Widget _buildNewsCard(NewsArticle article) {
    return Card(
      margin: EdgeInsets.only(bottom: 16),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) =>
                  // Open in-app webview for article URL
                  // ignore: prefer_const_constructors
                  WebViewScreen(url: article.url),
            ),
          );
        },
        borderRadius: BorderRadius.circular(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (article.imageUrl != null) _buildNewsImage(article.imageUrl!),
            Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      _buildSentimentBadge(article.sentiment),
                      SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          article.source,
                          style: TextStyle(
                            color: Colors.grey[600],
                            fontSize: 12,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      Text(
                        _formatDate(article.publishedAt),
                        style: TextStyle(
                          color: Colors.grey[600],
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 12),
                  Text(
                    article.title,
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      height: 1.3,
                    ),
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                  ),
                  SizedBox(height: 8),
                  Text(
                    article.description,
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey[700],
                      height: 1.4,
                    ),
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNewsImage(String imageUrl) {
    return ClipRRect(
      borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
      child: Image.network(
        imageUrl,
        height: 200,
        width: double.infinity,
        fit: BoxFit.cover,
        errorBuilder: (context, error, stackTrace) {
          return Container(
            height: 200,
            color: Colors.grey[300],
            child: Icon(Icons.image_not_supported, size: 50),
          );
        },
      ),
    );
  }

  Widget _buildSentimentBadge(String sentiment) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: _getSentimentColor(sentiment).withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: _getSentimentColor(sentiment),
          width: 1,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            _getSentimentIcon(sentiment),
            size: 14,
            color: _getSentimentColor(sentiment),
          ),
          SizedBox(width: 4),
          Text(
            sentiment.toUpperCase(),
            style: TextStyle(
              color: _getSentimentColor(sentiment),
              fontSize: 11,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.article_outlined, size: 80, color: Colors.grey[400]),
          SizedBox(height: 16),
          Text(
            'No news available',
            style: TextStyle(fontSize: 18, color: Colors.grey[600]),
          ),
          SizedBox(height: 8),
          ElevatedButton.icon(
            onPressed: _loadNews,
            icon: Icon(Icons.refresh),
            label: Text('Retry'),
          ),
        ],
      ),
    );
  }

  Color _getSentimentColor(String sentiment) {
    switch (sentiment) {
      case 'positive':
        return Colors.green;
      case 'negative':
        return Colors.red;
      case 'neutral':
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }

  IconData _getSentimentIcon(String sentiment) {
    switch (sentiment) {
      case 'positive':
        return Icons.trending_up;
      case 'negative':
        return Icons.trending_down;
      case 'neutral':
        return Icons.remove;
      default:
        return Icons.help_outline;
    }
  }

  String _formatDate(String dateString) {
    try {
      final date = DateTime.parse(dateString);
      final now = DateTime.now();
      final diff = now.difference(date);

      if (diff.inDays == 0) {
        if (diff.inHours == 0) {
          return '${diff.inMinutes}m ago';
        }
        return '${diff.inHours}h ago';
      } else if (diff.inDays < 7) {
        return '${diff.inDays}d ago';
      } else {
        return '${date.day}/${date.month}/${date.year}';
      }
    } catch (e) {
      return '';
    }
  }
}
