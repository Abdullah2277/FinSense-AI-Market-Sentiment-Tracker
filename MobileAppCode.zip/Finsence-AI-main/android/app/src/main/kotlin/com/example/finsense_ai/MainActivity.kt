package com.example.finance_news_sentiment

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
